#Topic:Loan Amount Prediction
#problem:Predict if a loan will get approved or not.
#-----------------------------------------------------------#--------------------------
#reading the dataset 
train <- read.csv("train.csv")
test <- read.csv("test.csv")

#finding the missing value in trai dataset
#-------------------------------------------------
sapply(train, function(x) sum(is.na(x)))

#selecting dropping the target variable
#---------------------------------------------
target<-train$Loan_Status

#tatget variable
#-----------------------------------------------------
table(train$Loan_Status)

prop.table(table(train$Loan_Status))
summary(train$Gender)
test$Loan_status <- rep(0, 367)

submit <- data.frame(Loan_ID = test$Loan_ID, Loan_status = test$Loan_status)
write.csv(submit, file = "file1.csv", row.names = FALSE)

#gender class mmdel
#------------------------------
summary(train$Gender)
summary(test$Gender)
train$Gender[train$Gender==""]=NA
train$Gender=as.numeric(train$Gender)-2
train$Married[train$Married==""]=NA
train$Married=as.numeric(train$Married)-2
train$Dependents[train$Dependents==""]=NA
train$Dependents=as.numeric(train$Dependents)-1
train$Self_Employed[train$Self_Employed==""]=NA
train$Self_Employed=as.numeric(train$Self_Employed)-2
train$Education=as.numeric(train$Education)-1
train$Property_Area=as.numeric(train$Property_Area)
train$Loan_Amount_Term=as.numeric(train$Loan_Amount_Term)

#for the test data
test$Gender[test$Gender==""]=NA
test$Gender=as.numeric(test$Gender)-2
test$Married[test$Married==""]=NA
test$Married=as.numeric(test$Married)+1
test$Dependents[test$Dependents==""]=NA
test$Dependents=as.numeric(test$Dependents)-1
test$Self_Employed[test$Self_Employed==""]=NA
test$Self_Employed=as.numeric(test$Self_Employed)-2
test$Education=as.numeric(test$Education)-1
test$Property_Area=as.numeric(test$Property_Area)
test$Loan_Amount_Term=as.numeric(test$Loan_Amount_Term)

View(test)
write.csv(test, file = "AfterImputation.csv", row.names = FALSE)
write.csv(test, file = "AfterImputationtest.csv", row.names = FALSE)

#lets visualize and see the result
#-------------------------------------------
library(ggplot2)
install.packages("plotly")
library(plotly)
var1<-train[grep(1, train$Education, ignore.case=T),]
View(var1)
#impute the missing values
#-------------------------------
library(Hmisc)
library(ggplot2)
library(lattice)
library(survival)
library(Formula)
impute_arg <- aregImpute(~Credit_History+LoanAmount+Gender+Married+Self_Employed+Dependents, data = test, n.impute = 1)
View(test)
q()
write.table (impute_arg$imputed$Gendr, file = "train.csv", sep = ";", col.names = NA, append = TRUE, dec =",") 

train$Gender[is.na(train$Gender)]<-impute_arg$imputed$Gender
train$Married[is.na(train$Married)]<-impute_arg$imputed$Married
train$Self_Employed[is.na(train$Self_Employed)]<-impute_arg$imputed$Self_Employed
train$LoanAmount[is.na(train$LoanAmount)]<-impute_arg$imputed$LoanAmount
train$Credit_History[is.na(train$Credit_History)]<-impute_arg$imputed$Credit_History
train$Dependents[is.na(train$Dependents)]<-impute_arg$imputed$Dependents

#for the test data set
#-----------------------------
test$Gender[is.na(test$Gender)]<-impute_arg$imputed$Gender
test$Married[is.na(test$Married)]<-impute_arg$imputed$Married
test$Self_Employed[is.na(test$Self_Employed)]<-impute_arg$imputed$Self_Employed
test$LoanAmount[is.na(test$LoanAmount)]<-impute_arg$imputed$LoanAmount
test$Credit_History[is.na(test$Credit_History)]<-impute_arg$imputed$Credit_History
test$Dependents[is.na(test$Dependents)]<-impute_arg$imputed$Dependents
View(test)

train_f=train
train_f$income=train_f$ApplicantIncome+train_f$CoapplicantIncome
test$income=test$ApplicantIncome+test$CoapplicantIncome

train_f$ratio=(train_f$LoanAmount*1000)/train_f$income
test$ratio=(test$LoanAmount*1000)/test$income

#prediction
#---------------------------
library(rpart)
require(rpart)
require(rpart.plot)
tree=rpart(Loan_Status~Credit_History+Property_Area+ApplicantIncome+ratio,data = train_f,minbucket=5,cp=.01)
prp(tree)
pred_tree=predict(tree,newdata = test,type = "class")
table(pred_tree)
submit <- data.frame(Loan_ID = test$Loan_ID, Loan_status = pred_tree)
MySubmission = data.frame(Loan_ID=Loan_ID,Loan_Status=pred_tree,data=)
write.csv(submit, "sample_submission.csv", row.names=FALSE)
submit$Loan_status=as.numeric(submit$Loan_status)

q()
